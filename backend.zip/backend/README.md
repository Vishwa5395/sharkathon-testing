Backend: copy .env.example to .env, npm install, npm run seed, npm start
